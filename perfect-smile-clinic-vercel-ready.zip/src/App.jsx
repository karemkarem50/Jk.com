
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { useState } from 'react';

const Header = () => (
  <header className="bg-white shadow p-4 flex justify-between items-center sticky top-0 z-50">
    <h1 className="text-2xl font-bold text-blue-600">عيادة الابتسامة المثالية</h1>
    <nav className="space-x-4">
      <Link to="/" className="text-gray-700 hover:text-blue-500">الرئيسية</Link>
      <Link to="/about" className="text-gray-700 hover:text-blue-500">من نحن</Link>
      <Link to="/services" className="text-gray-700 hover:text-blue-500">الخدمات</Link>
      <Link to="/team" className="text-gray-700 hover:text-blue-500">الفريق</Link>
      <Link to="/gallery" className="text-gray-700 hover:text-blue-500">المعرض</Link>
      <Link to="/faq" className="text-gray-700 hover:text-blue-500">الأسئلة</Link>
      <Link to="/contact" className="text-gray-700 hover:text-blue-500">تواصل</Link>
    </nav>
  </header>
);

const Footer = () => (
  <footer className="bg-gray-100 text-center p-4 mt-10 text-sm text-gray-600">
    © 2025 عيادة الابتسامة المثالية. جميع الحقوق محفوظة.
  </footer>
);

const Home = () => (
  <main className="text-center p-10 space-y-6">
    <h2 className="text-3xl font-bold text-blue-700">ابتسامتك تبدأ من هنا</h2>
    <p className="text-lg">نحن نوفّر رعاية أسنان احترافية باستخدام أحدث التقنيات الطبية.</p>
    <a href="https://wa.me/972598765432" className="bg-green-500 text-white px-6 py-3 rounded-full text-lg shadow hover:bg-green-600 transition">تواصل عبر واتساب</a>
  </main>
);

const About = () => (
  <section className="p-10 max-w-3xl mx-auto space-y-4">
    <h2 className="text-2xl font-bold">من نحن</h2>
    <p>عيادتنا تقدم خدمات طب الأسنان منذ أكثر من 10 سنوات، بقيادة الدكتور أحمد سالم، أخصائي تجميل وزراعة الأسنان.</p>
  </section>
);

const Services = () => (
  <section className="p-10 max-w-4xl mx-auto">
    <h2 className="text-2xl font-bold mb-6 text-center">خدماتنا</h2>
    <div className="grid md:grid-cols-3 gap-6">
      {["تنظيف الأسنان", "تبييض الأسنان", "زراعة الأسنان", "تقويم الأسنان", "حشوات تجميلية", "علاج العصب"].map((service, i) => (
        <div key={i} className="bg-white shadow p-4 rounded-xl text-center">
          <h3 className="font-semibold text-blue-600">{service}</h3>
        </div>
      ))}
    </div>
  </section>
);

const Team = () => (
  <section className="p-10 text-center">
    <h2 className="text-2xl font-bold mb-6">فريقنا</h2>
    <p>يتكون من نخبة من أطباء الأسنان المتخصصين ومساعدين مدرّبين لضمان أفضل رعاية.</p>
  </section>
);

const Gallery = () => (
  <section className="p-10 text-center">
    <h2 className="text-2xl font-bold mb-6">المعرض</h2>
    <p className="text-gray-500">صور قبل وبعد - سيتم إضافتها لاحقًا</p>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
      {[...Array(4)].map((_, i) => (
        <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
      ))}
    </div>
  </section>
);

const FAQ = () => (
  <section className="p-10 max-w-3xl mx-auto">
    <h2 className="text-2xl font-bold mb-4">الأسئلة الشائعة</h2>
    <div className="space-y-4">
      <details className="bg-gray-100 p-4 rounded-xl">
        <summary className="font-medium cursor-pointer">هل تبييض الأسنان يضر الأسنان؟</summary>
        <p className="mt-2">عند إجرائه بشكل مهني وآمن، لا يسبب التبييض ضررًا للأسنان.</p>
      </details>
      <details className="bg-gray-100 p-4 rounded-xl">
        <summary className="font-medium cursor-pointer">ما مدة زراعة الأسنان؟</summary>
        <p className="mt-2">تستغرق العملية عدة أشهر لتثبيت الزرعة والسن الجديد.</p>
      </details>
    </div>
  </section>
);

const Contact = () => {
  const [form, setForm] = useState({ name: '', message: '' });

  return (
    <section className="p-10 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">تواصل معنا</h2>
      <form className="space-y-4">
        <input className="w-full p-3 border rounded-xl" placeholder="الاسم" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <textarea className="w-full p-3 border rounded-xl" placeholder="رسالتك" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}></textarea>
        <button type="submit" className="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700">إرسال</button>
      </form>
    </section>
  );
};

export default function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/team" element={<Team />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
      <Footer />
    </Router>
  );
}
